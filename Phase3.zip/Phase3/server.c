#define _GNU_SOURCE
#define _POSIX_SOURCE
#define MAX_INPUT_SIZE 16382
#define MAX_COUNT_COMMANDS 128
#define PORT 5956
#define SA struct sockaddr

/// IMPORTS ///
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <stdbool.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <pthread.h>





void entry(){
	/*
		No params
		This is the landing message that appears on the screen
	*/
	fprintf(stdout,"*******************\n");
	fprintf(stdout, "** SHELL by Andriy and Nurgazy **\n");
	fprintf(stdout,"** please refer to the report for tutorial **\n");
	fprintf(stdout,"** available: all atomic shell commands (<cmd>[optional params]) **\n");
	fprintf(stdout,"** available: indefinite pipes (<cmd> | <cmd> | <cmd> ...) **\n");
	fprintf(stdout,"** i/o redirect (>, <) **\n");
	fprintf(stdout,"*******************\n");
}


void cut_cmds(char *cmds[], char *this_command[],int left,int right ){
	/*
		This function is used to split the array of commands into two arrays
		We use it to recurse on command array later.

		@param: arr cmds: array of all commands, ex ls -la | grep hello_world
		@param: arr this_command: the command we want to segment, ex ls -la
		@param: int left, right: bounds we want to have
	*/
	int j = 0;
	for(int i =left; i<right; i++){
		this_command[j++] = cmds[i];
	}
	return;
}

void single_command(char *cmds[], int command_count, int client_socket){
	/*
		This is a simple function to exec the command we are given
		It deals with I/O redirect as well

		@param: arr cmds: array of all commands, ex ls -la
		@param: int command_count: count of parameters in the command
	*/
	bool caret = false; // check for caret
	bool out = false; // if caret is it INPUT or OUTPUT redirect
	// let's do i/o redirect
	for(int i = 0; i<command_count-1; i++){
		if((strcmp(cmds[i],">")==0) || (strcmp(cmds[i],"<")==0)){
			if( (i!=command_count-3) || (i==0)){
				fprintf(stderr, "Improper use of caret!\n");
				exit(EXIT_FAILURE);
			}
			caret = true;
			if (strcmp(cmds[i],">")==0) out = true;
		}
	}

	// if no caret just run normally
	if(!caret){
		// terminate on "exit"
		if(strcmp(cmds[0], "exit") == 0){
			fprintf(stdout, "Exiting the shell!\n");
			kill(getppid(), SIGINT);
			exit(1);
 		}
		if ((strcmp(cmds[0], "rm") == 0) || (strcmp(cmds[0], "mkdir") == 0)|| (strcmp(cmds[0], "cp") == 0)|| (strcmp(cmds[0], "mv") == 0)|| (strcmp(cmds[0], "touch") == 0) ){
    		send(client_socket, "", 1, 0);

		}
		execvp(cmds[0], cmds);
		fprintf(stderr, "Command %s does not exit\n", cmds[0]);
		exit(EXIT_FAILURE);
	}
	// if caret exists save the filename, extract the command, and run accordingly
	char *filename = cmds[command_count-2]; // filename is the second to last argument, since the last is NULL
	char *this_command[MAX_COUNT_COMMANDS];
	cut_cmds(cmds,this_command,0,  command_count-3);
	this_command[command_count-3] = NULL;

	// output redirect
	if (out){
		if (!freopen(filename, "w", stdout)) {
			fprintf(stderr, "Could not save output to file %s\n", filename);
			exit(EXIT_FAILURE);
		}
	}
	// input redirect
	else{
		if (!freopen(filename, "r", stdin)) {
			fprintf(stderr, "Could not open file %s\n", filename);
			exit(EXIT_FAILURE);
		}
	}

    send(client_socket, "", 1, 0);
	// execure the command required
	execvp(this_command[0], this_command);

    // SEND ACK TO CLIENT
	fprintf(stderr, "Command %s does not exit\n", this_command[0]);
	exit(EXIT_FAILURE);
}




void recurse_on_pipes(char *cmds[], int command_count, int client_socket){
	/*
		Recursive function to create pipes as needed and
		run as many piped commands as you want!

		@param: arr cmds: array of all commands, ex ls -la
		@param: int command_count: count of parameters in the command
	*/
	bool exists_pipe = false;
	int pipe_idx = -1;
	// is there a pipe in the command array?
	for(int i=0; i<command_count-1; i++){
		if((strcmp(cmds[i],"|")==0) || (strcmp(cmds[i],"||")==0)){
			exists_pipe = true;
			pipe_idx = i;
			break;
		}
	}

	// IF NO PIPE RUN SIMPLY ONE COMMAND
	if (pipe_idx == -1) {
		single_command(cmds, command_count, client_socket); // input into the command
		return;
	}

	// *** GET THE FIRST COMMAND ***
	char *this_command[MAX_COUNT_COMMANDS];
	cut_cmds(cmds,this_command,0,  pipe_idx);

	this_command[pipe_idx] = NULL;


	// ** ISOLATE THE REMAINING COMMANDS
	char *remaining_commands[MAX_COUNT_COMMANDS];

	// check if the command ends with a pipe, it can't be run
	if (pipe_idx+2 == command_count){
		fprintf(stderr, "Terminal commands ending with a pipe are not defined!\n");
		exit(EXIT_FAILURE);
	}

	cut_cmds(cmds,remaining_commands, pipe_idx+1, command_count);
	cmds = remaining_commands;
	command_count -= (pipe_idx+1);
	pipe_idx++;

	// CREATE A PIPE AND RUN THE FIRST COMMAND
	int fd1[2]; // pipe 1 for getting output from child 1 and giving it to child 2 also
	pid_t pid;

	if (pipe(fd1) < 0) {
		fprintf(stderr, "PIPE ERROR\n");
		exit(EXIT_FAILURE);
	}

	pid = fork();

	if (pid < 0) {
		fprintf(stderr, "FORK ERROR\n");
		exit(EXIT_FAILURE);
	}
	// CHILD TO RUN FIRST COMMAND
	else if (pid == 0){
		dup2(fd1[1], 1); // establish shared memory
		close(fd1[1]);
		close(fd1[0]);
		single_command(this_command, pipe_idx, client_socket);
	}
  // PARENT RECURSIVELY RUNS THE REST
	else{
		dup2(fd1[0], 0); // establish shared memory
		close(fd1[1]);
		close(fd1[0]);
		recurse_on_pipes(cmds,command_count, client_socket);
	}
}


int get_command(int client_socket){
	/*
		Parse and tokenize the input

		@param: NULL
	*/
	char input[MAX_INPUT_SIZE];
	char *commands[MAX_COUNT_COMMANDS];
	int command_count = 0;

	// shell prompt
	// fprintf(stdout, "~ ");
 	// fgets(input, sizeof(input), stdin);
    // bzero();

    memset(&input, 0, MAX_INPUT_SIZE);


	// read the message from client and copy it in buffer
	recv(client_socket , &input , sizeof(input),0);
    fprintf(stdout, "received %s", input);
    if (strncmp("exit", input, 4) == 0) {
        printf("\nClient disconnecting...\n");
		return 1;
	}
    dup2(client_socket, STDERR_FILENO);
    dup2(client_socket, STDOUT_FILENO);


	// strip input from \n
	input[strcspn(input, "\n")] = 0;

	// what is the split character for commands?
	const char split[2] = " ";

	char *token;
   token = strtok(input, split);// tokenize str on " "


   while( token != NULL ) {
		commands[command_count++] = token;
      token = strtok(NULL, split);
   }
	commands[command_count++] = NULL; // add a NULL as last part of the token, so that exec runs smoothly

	recurse_on_pipes(commands,command_count,client_socket ); // recurse now and see if there are pipes
	fflush(stdout);
    return 0;
}



// run the thread
void* ThreadRun (void * socket){
	int *sock=(int*)socket;
	int client_socket=*sock;


	int child_done = 0;
	for(;;){
		pid_t pid = fork();
		if(pid < 0){
			printf("FORK ERROR\n");
			exit(EXIT_FAILURE);
		}
			// Child getting and executing the command
		else if(pid == 0){
			child_done = get_command(client_socket);// LISTEN
		}
			// parent waiting for the child to execute
		else{
			wait(NULL); // wait &status
			// send(client_socket, "12341234", sizeof("12341234"), 0);
			// printf("ACK SENT!\n");
			continue;
		}
		if(child_done){
			printf("Disconnected client!\n");
			close(client_socket);
			break;
		}
	}


	close(client_socket);
	pthread_exit(NULL);
	return 0;
}



int32_t main(){


    // INIT THE SERVER
    int server_socket, client_socket;
    socklen_t len;
	struct sockaddr_in servaddr, cli;

	// socket create and verification
	server_socket = socket(AF_INET, SOCK_STREAM, 0);
	if (server_socket == -1) {
		printf("socket creation failed...\n");
		exit(0);
	}
	else
		printf("Socket successfully created..\n");

	// assign IP, PORT
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(PORT);

	// Binding newly created socket to given IP and verification
	if ((bind(server_socket, (SA*)&servaddr, sizeof(servaddr))) != 0) {
		printf("socket bind failed...\n");
		exit(0);
	}
	else
		printf("Socket successfully binded..\n");

	// Now server is ready to listen and verification
	if ((listen(server_socket, 5)) != 0) {
		printf("Listen failed...\n");
		exit(0);
	}
	else
		printf("Server listening..\n");
	len = sizeof(cli);

	// Accept the data packet from client and verification
    int child_done = 0;

    for(;;){
        client_socket = accept(server_socket, (SA*)&cli, &len);
        if (client_socket < 0) {
            printf("server accept failed...\n");
            exit(0);
        }
        else printf("server accept the client...\n");
		// Spin off a thread for this client!
		pthread_t th;
		pthread_create(&th,NULL,ThreadRun,&client_socket);

    }
	return EXIT_SUCCESS;
}










/*

[p1,p2,p3,p4,p5]





*/