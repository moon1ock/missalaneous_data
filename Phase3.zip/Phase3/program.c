#include <stdio.h>
void main()
{
    int i;
	printf("The first 10 natural numbers are:\n");
	for (i=1;i<=10;i++)
	{
		printf("%d ",i);
	}
printf("\n");
}