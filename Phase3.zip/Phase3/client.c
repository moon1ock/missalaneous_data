	// int get_msg = recv(client_socket,msg,1024*sizeof(char),0);
	// if(get_msg==-1){
	// 	printf("client suddenly disconnected...\n");
	// 	printf("we dropped him from the queue and continue\n");
	// 	return 0;
	// } 



#include <netdb.h>
#include <unistd.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/socket.h>
#define MAX 16382
#define PORT 5956
#define SA struct sockaddr

int sock_exit;
char response[MAX];
char buff[MAX];


void entry(){
	/*
		No params
		This is the landing message that appears on the screen
	*/
	fprintf(stdout,"*******************\n");
	fprintf(stdout, "** SHELL by Andriy and Nurgazy **\n");
	fprintf(stdout,"** please refer to the report for tutorial **\n");
	fprintf(stdout,"** available: all atomic shell commands (<cmd>[optional params]) **\n");
	fprintf(stdout,"** available: indefinite pipes (<cmd> | <cmd> | <cmd> ...) **\n");
	fprintf(stdout,"** i/o redirect (>, <) **\n");
	fprintf(stdout,"*******************\n");
}


void  INThandler(int sig)
{
    char  c;

    signal(sig, SIG_IGN);
    printf("\nCLTR+C recieved, exiting client!\n");

	send(sock_exit , "exit" , sizeof("exit"),0);
	close(sock_exit);
    exit(0);

}


void func(int sock)
{

    memset(&buff, 0, MAX*sizeof(char));

	int n, len;
	for (;;) {


        memset(&buff, 0, MAX*sizeof(char));

		printf("~ ");
		n = 0;

		// copy  message in the buffer
		while ((buff[n++] = getchar()) != '\n'){}

		send(sock , buff , sizeof(buff),0);
		if ((strncmp(buff, "exit", 4)) == 0) {
			printf("Client Exit...\n");
			break;
		}

        memset(&response, 0, MAX*sizeof(char));
        recv(sock, response, MAX*sizeof(char),0); // receive input string from client
        printf( "%s", response);
        fflush(stdout);

	}
}

int main()
{
    // CATCH CTRL+C
    signal(SIGINT, INThandler);
	int sock;
	struct sockaddr_in servaddr, cli;

	// socket create and verification
	sock = socket(AF_INET, SOCK_STREAM, 0);
    sock_exit = sock;
	if (sock == -1) {
		printf("socket creation failed...\n");
		exit(0);
	}
	else
		printf("Socket successfully created..\n");

	// assign IP, PORT
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = INADDR_ANY;
	servaddr.sin_port = htons(PORT);

	// connect the client socket to server socket
	if (connect(sock, (SA*)&servaddr, sizeof(servaddr)) != 0) {
		printf("connection with the server failed...\n");
		exit(0);
	}
	else
		printf("connected to the server..\n");

	entry();
	// function for shell
	func(sock);

	// close the socket
	close(sock);
}